import { Module } from '@nestjs/common';
import { AiVercelController as AiVercelController } from './controllers/ai-agent.controller';
import { AiVercelService as AiVercelService } from './services/ai-vercel.service';
import { DialogsModule } from '../dialogs/dialogs.module';
import { CartsModule } from '../carts/carts.module';

@Module({
  imports: [DialogsModule, CartsModule],
  controllers: [AiVercelController],
  providers: [AiVercelService],
  exports: [AiVercelService],
})
export class AiVercelModule {}
