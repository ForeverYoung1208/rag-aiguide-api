export const KNOWLEDGE_BASE_SERVICE_TOKEN = 'knowledge-base-service-token';
export const MAX_AI_STEP_COUNT = 10;
