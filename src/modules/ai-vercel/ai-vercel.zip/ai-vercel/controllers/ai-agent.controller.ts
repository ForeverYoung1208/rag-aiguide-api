import { Controller, Query, Sse } from '@nestjs/common';
import {
  ApiOkResponse,
  ApiOperation,
  ApiProduces,
  getSchemaPath,
} from '@nestjs/swagger';
import { Observable } from 'rxjs';
import { MyMessageEventDto } from '../../../dto/message-event.dto';
import { DialogIdentifiersDto } from '../../dialogs/dto/dialog-identifiers.dto';
import { DialogsService } from '../../dialogs/services/dialogs.service';
import { AiVercelService } from '../services/ai-vercel.service';

@Controller('ai-agent')
export class AiVercelController {
  constructor(
    private readonly aiAgentService: AiVercelService,
    private readonly dialogsService: DialogsService,
  ) {}

  @Sse('send-dialog-to-ai')
  @ApiOperation({
    summary: 'Send dialog to AI',
    description:
      'Opens a Server-Sent Events stream with AI response chunks for the given dialog and phrase.',
  })
  @ApiProduces('text/event-stream')
  @ApiOkResponse({
    description: 'SSE stream of AI response chunks',
    type: MyMessageEventDto,
    content: {
      'text/event-stream': {
        schema: {
          $ref: getSchemaPath(MyMessageEventDto),
        },
      },
    },
  })
  async stream(
    @Query() dialogIdentifiers: DialogIdentifiersDto,
  ): Promise<Observable<MyMessageEventDto>> {
    await this.dialogsService.checkSseToken(dialogIdentifiers);
    return this.aiAgentService.sendDialogToAiStreamed(dialogIdentifiers.id);
  }
}
